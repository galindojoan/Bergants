package cat.copernic.bergants.model

import androidx.annotation.Keep

@Keep
data class BusModel(val ubicacioBus: String, val horariBus: String, val placesBus: String)
